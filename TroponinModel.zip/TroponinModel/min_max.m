function [v_max, t_max, index_v] = min_max(Cp_ctnt, t)

diffCp_ctnt = diff(Cp_ctnt);
idx_mins = [];

for idx_min = 1:length(diffCp_ctnt)-1
    if diffCp_ctnt(idx_min)*diffCp_ctnt(idx_min+1)<0
        idx_mins = [idx_mins, idx_min+1];
    end
end

t_max = [];
v_max = [];

[v_max(1), id] = max(Cp_ctnt);
t_max(1) = t(id);


t_max(2) = t(idx_mins(end));
v_max(2) = Cp_ctnt(idx_mins(end));

index_v = find(ismember(t, t_max));